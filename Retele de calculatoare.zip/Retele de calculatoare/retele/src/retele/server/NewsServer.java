package retele.server;

import retele.channel.Channel;
import retele.user.User;

import java.io.*;
import java.net.*;
import java.util.*;
import java.util.concurrent.ConcurrentHashMap;

public class NewsServer {
    private static final List<String> forbiddenWords = Arrays.asList("fuck", "shit", "bitch", "asshole", "bastard");
    private static final Map<String, Channel> channels = new ConcurrentHashMap<>();
    private static final Set<ClientHandler> clients = ConcurrentHashMap.newKeySet();

    public static void main(String[] args) {
        int port = 3000;

        try (ServerSocket serverSocket = new ServerSocket(port)) {
            System.out.println("Serverul este pornit și ascultă pe portul " + port);

            while (true) {
                Socket clientSocket = serverSocket.accept();
                ClientHandler clientHandler = new ClientHandler(clientSocket);
                clients.add(clientHandler);
                new Thread(clientHandler).start();
            }
        } catch (IOException e) {
            System.err.println("Eroare la pornirea serverului: " + e.getMessage());
        }
    }

    private static class ClientHandler implements Runnable {
        private Socket clientSocket;
        private PrintWriter out;
        private BufferedReader in;
        private User user;

        public ClientHandler(Socket socket) {
            this.clientSocket = socket;
        }

        @Override
        public void run() {
            try {
                out = new PrintWriter(clientSocket.getOutputStream(), true);
                in = new BufferedReader(new InputStreamReader(clientSocket.getInputStream()));

                out.println("Introduceți numele de utilizator:");
                String username = in.readLine();
                user = new User(username);

                out.println("Conectat ca " + username);
                sendChannelList();

                String inputLine;
                while ((inputLine = in.readLine()) != null) {
                    handleClientMessage(inputLine);
                }
            } catch (IOException e) {
                System.out.println("Eroare la comunicarea cu clientul: " + e.getMessage());
            } finally {
                try {
                    clientSocket.close();
                } catch (IOException e) {
                    System.out.println("Eroare la închiderea conexiunii clientului: " + e.getMessage());
                }
                clients.remove(this);
            }
        }

        private void sendChannelList() {
            out.println("Canale disponibile:");
            for (Channel channel : channels.values()) {
                out.println(channel);
            }
        }

        private void handleClientMessage(String message) {
            String[] parts = message.split(" ", 2);
            String command = parts[0].toLowerCase();
            String argument = parts.length > 1 ? parts[1] : null;

            switch (command) {
                case "publish":
                    handlePublishChannel(argument);
                    break;
                case "delete":
                    handleDeleteChannel(argument);
                    break;
                case "subscribe":
                    handleSubscribeChannel(argument);
                    break;
                case "unsubscribe":
                    handleUnsubscribeChannel(argument);
                    break;
                case "post":
                    handlePostNews(argument);
                    break;
                default:
                    out.println("Comandă necunoscută.");
            }
        }

        private void handlePublishChannel(String argument) {
            if (argument == null || !argument.contains(":")) {
                out.println("Format incorect. Utilizați: publish <nume>:<descriere>");
                return;
            }
            String[] parts = argument.split(":", 2);
            String name = parts[0].trim();
            String description = parts[1].trim();

            if (channels.containsKey(name)) {
                out.println("Canalul există deja.");
                return;
            }

            Channel channel = new Channel(name, description, user.getUsername());
            channels.put(name, channel);
            broadcastMessage("Noul canal publicat: " + channel);
        }

        private void handleDeleteChannel(String argument) {
            if (argument == null || argument.trim().isEmpty()) {
                out.println("Format incorect. Utilizați: delete <nume>");
                return;
            }
            String name = argument.trim();

            Channel channel = channels.get(name);
            if (channel == null) {
                out.println("Canalul nu există.");
                return;
            }
            if (!channel.getOwner().equals(user.getUsername())) {
                out.println("Nu aveți permisiunea să ștergeți acest canal.");
                return;
            }

            channels.remove(name);
            broadcastMessage("Canalul șters: " + name);
        }

        private void handleSubscribeChannel(String argument) {
            if (argument == null || argument.trim().isEmpty()) {
                out.println("Format incorect. Utilizați: subscribe <nume>");
                return;
            }
            String name = argument.trim();

            if (!channels.containsKey(name)) {
                out.println("Canalul nu există.");
                return;
            }

            user.subscribe(name);
            out.println("Abonat la canalul: " + name);
        }

        private void handleUnsubscribeChannel(String argument) {
            if (argument == null || argument.trim().isEmpty()) {
                out.println("Format incorect. Utilizați: unsubscribe <nume>");
                return;
            }
            String name = argument.trim();

            if (!user.getSubscribedChannels().contains(name)) {
                out.println("Nu sunteți abonat la acest canal.");
                return;
            }

            user.unsubscribe(name);
            out.println("Dezabonat de la canalul: " + name);
        }

        private void handlePostNews(String argument) {
            if (argument == null || !argument.contains(":")) {
                out.println("Format incorect. Utilizați: post <canal>:<mesaj>");
                return;
            }
            String[] parts = argument.split(":", 2);
            String channelName = parts[0].trim();
            String news = parts[1].trim();

            Channel channel = channels.get(channelName);
            if (channel == null) {
                out.println("Canalul nu există.");
                return;
            }
            if (!channel.getOwner().equals(user.getUsername())) {
                out.println("Nu aveți permisiunea să postați pe acest canal.");
                return;
            }

            for (String word : forbiddenWords) {
                if (news.contains(word)) {
                    out.println("Mesajul conține cuvinte interzise și nu a fost postat.");
                    return;
                }
            }

            broadcastNews(channelName, news);
        }

        private void broadcastMessage(String message) {
            for (ClientHandler client : clients) {
                client.out.println(message);
            }
        }

        private void broadcastNews(String channelName, String news) {
            for (ClientHandler client : clients) {
                if (client.user.getSubscribedChannels().contains(channelName)) {
                    client.out.println("Știri noi pe canalul " + channelName + ": " + news);
                }
            }
        }
    }
}
