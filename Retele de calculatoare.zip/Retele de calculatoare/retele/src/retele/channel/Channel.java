package retele.channel;

public class Channel {
    private String name;
    private String description;
    private String owner;

    public Channel(String name, String description, String owner) {
        this.name = name;
        this.description = description;
        this.owner = owner;
    }

    public String getName() {
        return name;
    }

    public String getDescription() {
        return description;
    }

    public String getOwner() {
        return owner;
    }

    @Override
    public String toString() {
        return name + ": " + description + " (publicat de " + owner + ")";
    }
}
