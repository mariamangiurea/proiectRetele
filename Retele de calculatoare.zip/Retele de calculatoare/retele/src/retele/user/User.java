package retele.user;

import java.util.HashSet;
import java.util.Set;

public class User {
    private String username;
    private Set<String> subscribedChannels;

    public User(String username) {
        this.username = username;
        this.subscribedChannels = new HashSet<>();
    }

    public String getUsername() {
        return username;
    }

    public Set<String> getSubscribedChannels() {
        return subscribedChannels;
    }

    public void subscribe(String channelName) {
        subscribedChannels.add(channelName);
    }

    public void unsubscribe(String channelName) {
        subscribedChannels.remove(channelName);
    }
}
