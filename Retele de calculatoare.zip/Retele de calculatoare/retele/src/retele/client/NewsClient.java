package retele.client;

import java.io.*;
import java.net.*;

public class NewsClient {
    public static void main(String[] args) {
        String hostName = "localhost";
        int port = 3000;

        try (Socket echoSocket = new Socket(hostName, port);
             PrintWriter out = new PrintWriter(echoSocket.getOutputStream(), true);
             BufferedReader in = new BufferedReader(new InputStreamReader(echoSocket.getInputStream()));
             BufferedReader stdIn = new BufferedReader(new InputStreamReader(System.in))) {

            System.out.println(in.readLine());
            String username = stdIn.readLine();
            out.println(username);
            System.out.println(in.readLine());

            String fromServer;
            String fromUser;

            new Thread(() -> {
                try {
                    String inputLine;
                    while ((inputLine = in.readLine()) != null) {
                        System.out.println(inputLine);
                    }
                } catch (IOException e) {
                    System.out.println("Conexiune închisă: " + e.getMessage());
                }
            }).start();

            while ((fromUser = stdIn.readLine()) != null) {
                out.println(fromUser);
            }
        } catch (UnknownHostException e) {
            System.err.println("Host necunoscut: " + hostName);
        } catch (IOException e) {
            System.err.println("Nu se poate comunica cu serverul: " + hostName);
        }
    }
}
